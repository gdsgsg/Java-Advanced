package multidimensionalArrays;

import java.util.Scanner;

public class IntersectionOfTwoMatrices_03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //1. въвеждаме размерите на матриците
        int rows = Integer.parseInt(scanner.nextLine());
        int cols = Integer.parseInt(scanner.nextLine());

        //2. създаваме матриците, с които ще работим
        String[][] matrixA = new String[rows][cols];
        String[][] matrixB = new String[rows][cols];

        //3. пълним матриците
        fillMatrix(matrixA, scanner);
        fillMatrix(matrixB, scanner);

        //4. обработваме матрици
        for (int row = 0; row <= rows - 1; row++) {
            for (int col = 0; col <= cols - 1; col++) {
                String elementA = matrixA[row][col];
                String elementB = matrixB[row][col];

                //ако елементите съвпадат
                if (elementA.equals(elementB)) {
                    System.out.print(elementA + " ");
                }
                //елементите да не съвпадат
                else {
                    System.out.print("* ");
                }
            }
            System.out.println(); //свали курсора на нов ред, за да отпечатваме данните на нов ред
        }

    }

    //метод, който ми въввежда данни в текстова матрица
    private static void fillMatrix(String[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            matrix[row] = scanner.nextLine().split("\\s+");
        }
    }
}
