package multidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class SumMatrixElements_04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //1. въвеждаме размерите на матрицата
        String dimensions = scanner.nextLine(); //"3, 6"
        //"3, 6".split(", ") -> ["3", "6"]
        int rows = Integer.parseInt(dimensions.split(", ")[0]); //3
        int cols = Integer.parseInt(dimensions.split(", ")[1]); //6

        //2. създаваме матрицата
        int[][] matrix = new int[rows][cols];

        //3. пълним матрицата с данни от конзолата
        fillMatrix(matrix, scanner);

        //4. намираме сумата на елементите в матрицата
        int sum = getSumMatrixElements(matrix);

        //5. отпечатване
        System.out.println(rows);
        System.out.println(cols);
        System.out.println(sum);

    }

    //метод, който пълни с данни от конзолата целочислена матрица
    private static void fillMatrix(int[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            matrix[row] = Arrays.stream(scanner.nextLine().split(", "))
                    .mapToInt(Integer::parseInt).toArray();
        }
    }

    //метод, който приема матрица -> изчислява и връща сумата от елементите
    private static int getSumMatrixElements (int[][] matrix) {
        int sum = 0; //сума на елементите на матрицата

        for (int row = 0; row <= matrix.length - 1; row++) {
            for (int col = 0; col <= matrix[0].length - 1; col++) {
                int currentElement = matrix[row][col];
                sum += currentElement;
            }
        }
        //обходили всички елементи и сме ги сумирали
        return sum;
    }
}
