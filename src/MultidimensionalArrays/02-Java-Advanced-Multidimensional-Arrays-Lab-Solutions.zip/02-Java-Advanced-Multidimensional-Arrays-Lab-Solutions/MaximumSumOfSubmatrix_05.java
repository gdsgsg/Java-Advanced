package multidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class MaximumSumOfSubmatrix_05 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //1. въвеждаме размерите на матрицата
        String dimensions = scanner.nextLine(); //"3, 6"
        //"3, 6".split(", ") -> ["3", "6"]
        int rows = Integer.parseInt(dimensions.split(", ")[0]);
        int cols = Integer.parseInt(dimensions.split(", ")[1]);

        //2. създаваме празна матрица
        int[][] matrix = new int[rows][cols];

        //3. пълним матрицата с данни от конзолата
        fillMatrix(matrix, scanner);

        //4. обходим всички матрици 2 по 2
        //!!!! елементите на последен ред и колона не могат да образуват матрици
        int maxSum = Integer.MIN_VALUE; //максималната сума от матриците

        int startRow = 0; //ред, от който ми започва макс матрица
        int startCol = 0; //колона, от който ми започва макс матрица

        for (int row = 0; row < rows - 1; row++) {
            for (int col = 0; col < cols - 1; col++) {
                //създава се матрица от следните елементи
                //текущ елемент:  matrix[row][col]
                //дясно на текущия: matrix[row][col + 1]
                //по диагонал на текущия: matrix[row + 1][col + 1]
                // надолу от текущия: matrix[row + 1][col]

                int sumOfSubmatrix = matrix[row][col] + matrix[row][col + 1] +
                                     matrix[row + 1][col + 1] + matrix[row + 1][col];

                if (sumOfSubmatrix > maxSum) {
                    maxSum = sumOfSubmatrix;
                    //запазваме от кой елемент ми започва марицата
                    startRow = row;
                    startCol = col;
                }
            }
        }

        //5. отпечатване
        //матрицата, с най-голяма сума
        //startRow -> реда, от който започва матрицата
        //startCol -> колона, от коята започва матрицата
        System.out.print(matrix[startRow][startCol] + " ");
        System.out.println(matrix[startRow][startCol + 1] + " ");
        System.out.print(matrix[startRow + 1][startCol] + " ");
        System.out.println(matrix[startRow + 1][startCol + 1]);

        //най-голяма сума
        System.out.println(maxSum);
    }

    //метод, който пълни целочислена матрица с данни от конзолата
    private static void fillMatrix(int[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            matrix[row] = Arrays.stream(scanner.nextLine().split(", "))
                    .mapToInt(Integer::parseInt).toArray();
        }
    }
}
