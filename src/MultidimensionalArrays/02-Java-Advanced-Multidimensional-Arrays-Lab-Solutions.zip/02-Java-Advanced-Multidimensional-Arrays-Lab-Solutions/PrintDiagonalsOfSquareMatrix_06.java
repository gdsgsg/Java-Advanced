package multidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class PrintDiagonalsOfSquareMatrix_06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //КВАДРАТНА МАТРИЦА -> важат зависимостите за диагоналите
        //1. въвеждаме размера на матрицата
        int n = Integer.parseInt(scanner.nextLine()); //брой редове = брой колони

        //2. създаваме празна матрица
        int [][] matrix = new int[n][n];

        //3. пълним матрицата с данни от конзолата
        fillMatrix(matrix, scanner);

        //4. отпечатваме елементите на главния диагонал
        printElementsOnPrimaryDiagonal(matrix);

        System.out.println();

        //5. отпечатваме елементите на второстепенния диагонал
        printElementsOnSecondaryDiagonal(matrix);
    }

    //метод, който отпечатва елементите на второстепенния диагонал
    private static void printElementsOnSecondaryDiagonal(int[][] matrix) {
        //бр. редове = matrix.length
        //бр. колони = matrix[0].length

        //бр. редове = бр. колони
        for (int col = 0; col <= matrix.length - 1; col++) {
            for (int row = 0; row <= matrix[0].length - 1; row++) {
                int currentElement = matrix[row][col];
                //проверка дали елемента се намира на второстепенния диагонал диагонал
                if (row + col == matrix.length - 1) {
                    System.out.print(currentElement + " ");
                }
            }
        }
    }

    //метод, който отпечатва елементите на главния диагонал
    private static void printElementsOnPrimaryDiagonal(int[][] matrix) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            for (int col = 0; col <= matrix[0].length - 1; col++) {
                int currentElement = matrix[row][col];
                //проверка дали елемента се намира на главния диагонал
                if (row == col) {
                    System.out.print(currentElement + " ");
                }
            }
        }
    }

    //метод, който пълни целочислена матрица с данни от конзолата
    private static void fillMatrix(int[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            matrix[row] = Arrays.stream(scanner.nextLine().split("\\s+"))
                    .mapToInt(Integer::parseInt).toArray();
        }
    }
}
