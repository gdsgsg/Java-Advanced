package multidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class PositionsOf_02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //1. въвеждаме размерите на матрицата (редове и колони)
        String matrixDimensions = scanner.nextLine(); //"2 3"
        //"2 3".split(" ") -> ["2", "3"]
        int rows = Integer.parseInt(matrixDimensions.split(" ")[0]); //2
        int cols = Integer.parseInt(matrixDimensions.split(" ")[1]); //3

        //2. създаваме матрицата
        int [][] matrix = new int[rows][cols];

        //3. пълним матрицата с данни от конзолата
        fillMatrix(matrix, scanner);

        //4. въвеждаме число, което да го търсим в матрицата
        int number = Integer.parseInt(scanner.nextLine());

        //5. обхождаме матрицата и търсим в нея въведеното число (number)
        boolean isFound = false; //дали сме намерили числото в матрицата или не
        //isFound = false -> не сме намерили числото
        //isFound = true -> сме намерили числото

        for (int row = 0; row <= matrix.length - 1; row++) {
            for (int col = 0; col <= matrix[0].length - 1; col++) {
                int currentElement = matrix[row][col];
                if (currentElement == number) {
                    //намерили сме числото в матрицата
                    System.out.println(row + " " + col);
                    isFound = true;
                }
            }
        }

        //6. след обхождането не сме намерили числото -> "not found"
        if (!isFound) {
            System.out.println("not found");
        }

    }

    //метод, който пълни целочислена матрица с данни, които са въведени от конзолата
    private static void fillMatrix(int[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            matrix[row] = Arrays.stream(scanner.nextLine().split("\\s+"))
                    .mapToInt(Integer::parseInt).toArray();
        }
    }
}
