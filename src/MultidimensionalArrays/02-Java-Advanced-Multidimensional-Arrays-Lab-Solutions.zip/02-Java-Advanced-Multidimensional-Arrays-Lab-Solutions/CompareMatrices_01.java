package multidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class CompareMatrices_01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //ВХОДНИ ДАННИ
        //1. въвеждаме измеренията на първата матрица
        String firstMatrixDimensions = scanner.nextLine(); //"2 3"
        //"2 3".split(" ") -> ["2", "3"]
        int rowsFirstMatrix = Integer.parseInt(firstMatrixDimensions.split(" ")[0]);
        int colsFirstMatrix = Integer.parseInt(firstMatrixDimensions.split(" ")[1]);
        //2. създаваме и пълним първата матрица с данни от конзолата
        int [][] firstMatrix = new int[rowsFirstMatrix][colsFirstMatrix];
        fillMatrix(firstMatrix, scanner);

        //3. въвеждаме измеренията на втората матрица
        String secondMatrixDimensions = scanner.nextLine(); //"4 5"
        //"4 5".split(" ") -> ["4", "5"]
        int rowsSecondMatrix = Integer.parseInt(secondMatrixDimensions.split(" ")[0]);
        int colsSecondMatrix = Integer.parseInt(secondMatrixDimensions.split(" ")[1]);
        //4. създаваме и пълним втората матрица с данни от конзолата
        int[][] secondMatrix = new int[rowsSecondMatrix][colsSecondMatrix];
        fillMatrix(secondMatrix, scanner);

        //ПРОВЕРКА ЗА ЕДНАКВОСТ НА МАТРИЦИТЕ
        if (isEqual(firstMatrix, secondMatrix)) {
            System.out.println("equal");
        } else {
            System.out.println("not equal");
        }

    }

    //метод, който проверява дали две матрици са еднакви
    //true -> ако двете матрици са еднакви
    //false -> ако двете матрици не са еднакви
    private static boolean isEqual (int[][] firstMatrix, int [][] secondMatrix) {
        //1. проверяваме дали броят на редовете им съвпада
        if (firstMatrix.length != secondMatrix.length) {
            //броя редовете им не съвпадат -> матриците не са еднакви
            return false;
        }

        //2. проверяваме дали броят на колоните им съвпада
        if (firstMatrix[0].length != secondMatrix[0].length) {
            //броя колоните им не съпадат -> матриците не са еднакви
            return false;
        }

        //3. проверим дали имат еднакво съдържание
        //двете матрици имат еднакъв брой редове и колони
        for (int row = 0; row <= firstMatrix.length - 1; row++) {
            for (int col = 0; col <= secondMatrix[0].length - 1; col++) {
                if (firstMatrix[row][col] != secondMatrix[row][col]) {
                    //различни елементи в матриците на еднакви места -> матриците не са еднакви
                    return false;
                }
            }
        }

        //броя на редовете съвпада
        //броя на колоните съвпада
        //елементите и на двете матрици съвпадат
        return true;
    }


    //метод, който пълни матрицата с данни от конзолата
    //целочислена
    private static void fillMatrix(int[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
                matrix[row] = Arrays.stream(scanner.nextLine().split("\\s+"))
                                .mapToInt(Integer::parseInt).toArray();
        }
    }

    //дробна
    private static void fillMatrix(double[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            matrix[row] = Arrays.stream(scanner.nextLine().split("\\s+"))
                    .mapToDouble(Double::parseDouble).toArray();
        }
    }

    //текстова
    private static void fillMatrix(String[][] matrix, Scanner scanner) {
        for (int row = 0; row <= matrix.length - 1; row++) {
            matrix[row] = scanner.nextLine().split("\\s+");
        }
    }
}
