package multidimensionalArrays;

import java.util.Scanner;

public class DemoMatrix {
    public static void main(String[] args) {

        //МАТРИЦА = ТАБЛИЦА = МАСИВ (СЪВКУПНОСТ) ОТ МАСИВИ
        //В МАТРИЦАТА СЪХРАНЯВАМ СЪВКУПНОСТ ОТ ЕДНОТИПНИ ЕЛЕМЕНТИ В ТАБЛИЧЕН ВИД
        //квадратна матрица => бр. редове = бр. колони
        //правоъгъклна матрица => бр. редове != бр. колони

        //създаване на празна матрица
        //!!! задължително задаваме брой на редове и на колони
        int [][] intMatrix = new int[4][3]; //редове = 4; колони = 3
        double [][] doubleMatrix = new double[5][5]; //редове = 5; колони = 5
        String [][] stringMatrix = new String[4][4]; // редове = 4; колони = 4

        //задаваме стойност на елемент от матрицата -> матрица[ред][колона] = 5;
        intMatrix[0][0] = 5;
        intMatrix[0][1] = 10;
        intMatrix[0][2] = 15;

        //достъпване на елементи -> матрица[ред][колона]
        int number = intMatrix[0][1];
        System.out.println(intMatrix[0][0]);

        //бр. редове = дължина на матрица
        int rows = intMatrix.length;
        System.out.println(intMatrix.length);// 4
        //бр. колони
        int cols = intMatrix[0].length;
        System.out.println(intMatrix[0].length); // 3

        //създаване на матрица с предварително зададени стойности
        int[][] numbers = {
                {1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12}
        };

        //обхождане на матрица -> вложени цикли
        //начин 1: по редове
        for (int row = 0; row <= numbers.length - 1; row++) {
            //за всеки един ред: обхождаме всяка една колона
            for (int col = 0; col <= numbers[0].length - 1; col++) {
                int element = numbers[row][col];
                System.out.println(element);
            }
        }

        //начин 2: по колони
        for (int col = 0; col <= numbers[0].length - 1; col++) {
            //за всяка една колона: обхождаме всеки един ред
            for (int row = 0; row <= numbers.length - 1; row++) {
                int element = numbers[row][col];
                System.out.println(element);
            }
        }





    }
}
