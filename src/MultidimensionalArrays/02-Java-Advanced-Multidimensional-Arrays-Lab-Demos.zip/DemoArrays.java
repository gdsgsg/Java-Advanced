package multidimensionalArrays;

import java.util.Arrays;
import java.util.Scanner;

public class DemoArrays {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //създаване на празен масив
        int [] numbers = new int[10];
        //numbers = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

        String[] names = new String[5];
        //names = [null, null, null, null, null]

        //дължина на масив = броя на елементите
        System.out.println(numbers.length);

        //достъп до елементите на масива
        numbers[0] = 5;
        System.out.println(numbers[3]);
        //numbers[76] = 9; //EXCEPTION: Index out of bounds

        //oбхождане на масив
        //1. foreach -> работим с елементите на масива, без да ни интересува позицията, на която се намират
        for (int number : numbers) {
            System.out.println(number);
        }

        //2. for -> работим с елементите на масива и техните позиции
        for (int position = 0; position <= numbers.length - 1; position++) {
            if (position % 2 == 0) {
                System.out.println(numbers[position]);
            }
        }

        //прочитане на масие от конзолата
        //1. масив от текстове
        //"Ivan, Stefan, Georgi, Peter".split(" ") -> ["Ivan", "Stefan", "Georgi", "Peter"]
        String[] texts = scanner.nextLine().split(", ");

        //2. масив от цели числа
        //"2 3 5 6 19 23".split(" ") -> ["2", "3", "5", "6", "19", "23"] -> [2, 3, 5, 6, 19, 23]
        int[] days = Arrays.stream(scanner.nextLine().split(" "))
                    .mapToInt(Integer::parseInt).toArray();

        //2. масив от дробни числа
        double[] grades = Arrays.stream(scanner.nextLine().split(" "))
                .mapToDouble(Double::parseDouble).toArray();

    }
}
