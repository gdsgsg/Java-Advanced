package stack_queue;

import java.util.ArrayDeque;
import java.util.Scanner;

public class BrowserHistory_01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String currentURL = "";
        ArrayDeque<String> browserHistory = new ArrayDeque<String>();

        String command = scanner.nextLine();
        while (!command.equals("Home")) {
            if (command.equals("back")) {
                //command = "back"
                //1. нямаме предишно достъпени сайтове -> не можем да се върнем назад
                if (browserHistory.size() <= 1) {
                    System.out.println("no previous URLs");
                }
                //2. имаме предишно достъпени сайтове -> можем да се върнем назад
                else {
                    browserHistory.pop(); //премахвам последния достъпен = текущия URL
                    currentURL = browserHistory.peek();
                    System.out.println(currentURL);
                }
            } else {
                //command = "www.softuni.bg"
                //1. отпечатваме името на достъпения сайт
                //2. добавяме го към history (stack)
                currentURL = command;
                System.out.println(currentURL);
                browserHistory.push(currentURL);
            }
            command = scanner.nextLine();
        }
    }
}
