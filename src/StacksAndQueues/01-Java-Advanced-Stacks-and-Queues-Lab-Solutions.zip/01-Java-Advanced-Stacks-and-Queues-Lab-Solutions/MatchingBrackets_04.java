package stack_queue;

import java.util.ArrayDeque;
import java.util.Scanner;

public class MatchingBrackets_04 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String expression = scanner.nextLine();
        //"1 + (2 - (2 + 3) * 4 / (3 + 1)) * 5"

        ArrayDeque<Integer> stack = new ArrayDeque<>(); //стартовите позиции на отворените скоби

        for (int position = 0; position <= expression.length() - 1; position++) {
            char currentSymbol = expression.charAt(position);
            if (currentSymbol == '(') {
                stack.push(position);
            } else if (currentSymbol == ')') {
                int positionOpenBracket = stack.pop();
                //позицията на отворената скоба -> positionOpenBracket
                //позицията на затворената скоба -> position
                System.out.println(expression.substring(positionOpenBracket, position + 1));
            }
        }
    }
}
