package stack_queue;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class HotPotato_06 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //входни данни
        ArrayDeque<String> queueKids = Arrays.stream(scanner.nextLine().split("\\s+"))
                                  .collect(Collectors.toCollection(ArrayDeque::new));

        int  countPasses = Integer.parseInt(scanner.nextLine());

        //повтаряме: подаваме картофа и отиваме отзад на опашката
        //стоп: децата <= 1
        //продължаваме: децата > 1

        while (queueKids.size() > 1) {
            //играем играта
            for (int i = 1; i < countPasses; i++) {
                String rotatedKid = queueKids.poll(); // подава картофа и се мести
                queueKids.offer(rotatedKid); //месети отзад на опашката
            }
            //подали картофа определения брой пъти -> излиза от играта детето, което държи в момента картофа
            System.out.println("Removed " + queueKids.poll());
        }

        //играта приключва -> в опашката имаме само 1 дете
        System.out.println("Last is " + queueKids.peek());
    }
}
