package stack_queue;

import java.util.ArrayDeque;
import java.util.Scanner;

public class DecimalToBinaryConvertor_03 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = Integer.parseInt(scanner.nextLine());

        ArrayDeque<Integer> stack = new ArrayDeque<>();

        //повтаряме:
        //1. делим числото на 2 и взимаме остатъка
        //2. добавяме остатъка към стек
        //стоп: число == 0
        //продължаваме: число != 0


        //част 1: преобразуваме числото
        while (number != 0) {
            int remainder = number % 2;
            stack.push(remainder);
            number = number / 2;
        }

        //част 2: отпечатваме числото в двоична бройна система
        if (stack.isEmpty()) {
            //въведеното число е 0
            System.out.println(0);
        } else {
            //въведеното число не е 0 -> отпечатаме остатъците
            while (!stack.isEmpty()) {
                System.out.print(stack.pop());
            }
        }
    }
}
