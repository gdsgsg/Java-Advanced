package stack_queue;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Scanner;
import java.util.stream.Collectors;

public class SimpleCalculator_02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayDeque<String> expression = Arrays.stream(scanner.nextLine().split("\\s+"))
                                        .collect(Collectors.toCollection(ArrayDeque::new));

        //"2 + 5 + 10 - 2 - 1".split("//s+") -> ["2", "+", "5", "+", "10", "-", "2", "-", "1"]

        //повтаряме:
        //1. взимаме и премахваме първите 3 елемента
        //2. извъшрвам действието
        //3. добавяме резултата
        //стоп: изразът се състои от 1 елемент
        //продължаваме: изразът има повече от 1 елемент

        while (expression.size() > 1) {
            int firstNumber = Integer.parseInt(expression.pop()); //"2" -> parse -> 2
            String operation = expression.pop(); //"+"
            int secondNumber = Integer.parseInt(expression.pop()); //"5" -> parse -> 5

            int result = 0; //резултат от извършената операция
            if (operation.equals("+")) {
                result = firstNumber + secondNumber;
            } else if (operation.equals("-")) {
                result = firstNumber - secondNumber;
            }

            //7 -> String.valueOf -> "7" -> push in stack of strings
            expression.push(String.valueOf(result));
        }

        //expression.size() <= 1
        //прекратяваме пресмятанията, когато останем с 1 елемент в стека -> какъв е крайният резултат от израза
        System.out.println(expression.peek());
    }
}
